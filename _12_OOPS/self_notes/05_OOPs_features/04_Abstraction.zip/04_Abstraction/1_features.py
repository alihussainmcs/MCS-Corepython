"""
1.Encapsulation:  Binding the data members and member methods into single entity(class/object)
-----------------
2. Abstraction : Hiding the implementation details
-----------------
3. Polymorphism :
-----------------
Static polymorphism  : method overloading
Dynamic polymorphism : method overriding

4. Inheritance  : Code re usability
---------------

"""
# emp.getdata().getcustomer().getaddres().save()
