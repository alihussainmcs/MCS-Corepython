# CRUD  Create

with open('second_file.txt', 'w') as f_file:
    data = f_file.write("I am writing the text in my second file .")
    f_file.close()

